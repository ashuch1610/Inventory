const dotenv = require("dotenv").config();
const express = require("express");
const mongooes = require("mongoose");
const bodyparser = require("body-parser");
const cors = require("cors");
const bodyParser = require("body-parser");
const userRoute = require("./routes/userRout")


var app = express();



//middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.json());

//Routes Middleware

app.use("/api/users",userRoute);

//Routes
app.get("/", (req , res)=>{
    res.send("Home Page");
});


// connect to DB and start server
const PORT = process.env.PORT || 5000;
mongooes 
        .connect(process.env.MONGO_URI)
        .then(()=>{
            app.listen(PORT, ()=> {
                console.log(`Server Running on port ${PORT}`)
            })
        })

        .catch((err) => console.log(err) )

        module.export = router;
        module.export = app;
        