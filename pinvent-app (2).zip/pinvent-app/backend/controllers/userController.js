const express = require("express");
const router = express.Router();

const registerUser = async (req , res)=> {
         res.send("Register User")
};

module.exports = {registerUser,
    router,
}

