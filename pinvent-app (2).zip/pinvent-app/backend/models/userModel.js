const mongooes = require("mongooes")

const userSchema = mongooes.Schema({

    name: {
        type: String,
        required: [true, "Please add a number"]

    },

    email: {
        type: String,
        required: [true,"Please add a email"],
        unique: true,
        trim: true,
        Match: [
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, "Please enter a valid emial"]


    },

    password: {
        type: String, 
        required: [true,"Please add a pasword"],
        MinLength: [6, "password must be 6 characters"],
        MaxLength: [23, "Paaword must not be more than 23 characters"],
    },

    photo: {
        type: String,
        required: [true, "Please add a photo"],
        default:"https//i.ibb.co/4pDNDk1/avatar.png"
    },

    phone: {
        type: String ,
        default: "+234"
    },
     
    bio: {
        type: String, 
        MaxLength: [23, "Paaword must not be more than 23 characters"],
        default:"bio",
    },
     

},
{
    timestamp: true,

} )

const user = mongooes.model("User","userSchema")
module.export = user;
module.export = router;